from ota import ota_manager
from uaiohttpclient import request
import requests

def test_ota():
    print('test_ota()')
    pass

def print_url(url='https://github.com/jp-irons/PicoWiFiOTA/raw/refs/heads/ota/releases/versions.json'):
    print('url ', url)
    source = requests.get(url)
    content = source.json()
    print(content)

import requests
import ujson as json
import time
url = "https://raw.githubusercontent.com/jp-irons/PicoWiFiOTA/refs/heads/ota/releases/build_v0.0.01.tar"
start = time.ticks_ms()
head = requests.head(url)
print(time.ticks_ms()-start)
response = requests.get(url, stream = True)
print(time.ticks_ms()-start)
# Get response code
response_code = response.status_code
print(time.ticks_ms()-start)
# Get response content
content = response.content
# attributes = json.loads(content)
print(time.ticks_ms()-start)


# Print results
print('Response code: ', response_code)
print('Response content:', content)
